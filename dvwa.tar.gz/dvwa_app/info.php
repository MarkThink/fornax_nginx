<?php

$fox=0;

phpinfo();